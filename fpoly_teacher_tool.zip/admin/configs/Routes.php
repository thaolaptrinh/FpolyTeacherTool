<?php

$routes[''] = 'admin';
$routes['default_controller'] = 'admin';



$routes['quan-ly/site'] = 'admin/site';
$routes['quan-ly/co-so'] = 'admin/co_so';
$routes['giao-vien'] = 'admin/teachers';
